export const Role = {
    Admin: 'Site Admin',
    Dealer: 'Dealer'   ,
    Manager: 'Manager',
    Cashier: 'Cashier',
    CreditCustomer: 'Credit Customer'
}
