import React, { Component } from "react";
import ReactDOM from "react-dom";
import { authService } from "@S";

class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      username: "",
      password: "",
      error: false,
    };

    if (authService.currentUserValue) {
      this.props.history.push("/dashboard");
    }
  }

  componentDidMount() {}

  onChange = (field) => {
    return (event) => {
      let state = {};
      state[field] = event.target.value;
      this.setState(state);
    };
  };

  onSubmit = () => {
    const { username, password } = this.state;
    var token;
    authService.login(username, password).then(
      (user) => {
        token = authService.currentUserToken;
        authService.bunkDetails(token).then(
          (user) => {
            this.props.history.push("/dashboard");
          },
          (error) => {
            console.log("error");
          }
        );
      },
      (error) => {
        this.setState({ error: true })
        console.log("error");
      }
    );
  };

  render() {
    return (
      <section className="login">
        <div className="wave-container --bottom">
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
        </div>
        <div className="wrapper">
          <div className="login-container">
            <div className="logo-wrapper"></div>
            <div className="content-wrapper">
              <h1>Sign in to manage your outlet</h1>
              <div className="form-wrapper">
                <div className="input-wrapper">
                  <input
                    type="text"
                    ref="username"
                    placeholder="Username"
                    onChange={this.onChange("username")}
                    className={this.state.error ? "error" : ""}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="password"
                    ref="password"
                    placeholder="Password"
                    onChange={this.onChange("password")}
                    className={this.state.error ? "error" : ""}
                  />
                </div>
                <div
                  className={
                    this.state.error
                      ? "error-wrapper --display"
                      : "error-wrapper"
                  }
                >
                  <p>Incorrect credentials</p>
                </div>
                <div className="input-submit-wrapper">
                  <input type="submit" value="Login" onClick={this.onSubmit} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="wave-container --top">
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
        </div>
      </section>
    );
  }
}

export default Login;
