import React, { Component } from 'react';
import { authService } from '@S';
import { Link } from 'react-router-dom';



class Header extends Component {
  constructor(props) {
    super(props);

    this.state = {
      time: new Date().toLocaleTimeString('en-US'),
      date: new Date().toDateString()
    }

  }

  currentTime() {
    this.setState({ time: new Date().toLocaleTimeString('en-US') });
  }

  componentDidMount () {
    this.interval = setInterval(() => this.currentTime(), 1000);
  }

  render() {
    const role = authService.currentUserRole;

    return (
        <div className="header-wrapper">
          <div className="header-left">
            <h4>Petrometer</h4>
          </div>
          <HeaderLinks role={authService.currentUserRole} title={this.props.title} />
          <div className="header-right">
            <ul>
            <li className="current-date">
              {this.state.date}{" , "}{this.state.time}
            </li>
              <li>
                <div className="search-wrapper">
                  <input type="text" placeholder="Search" />
                </div>
              </li>
              <li>
                <a href="#" className="drop-toggle user-account">Account</a>
                <ul className="sub-menu">
                  <li>
                    <Link to={`/account/${role.toLowerCase()}/settings`}>Account settings</Link>
                  </li>
                  <li>
                    <Link to="/logout">Logout</Link>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      );
  }
}

const HeaderLinks = ({role, title}) => {

  if (role === "Site Admin") {
    return (
      <>
       <div className="header-center">
         <h1>{title}</h1>
       </div>

      </>
     );
  }
  else if (role === "Dealer") {
    return (
     <>
        <div className="header-center">
         <h1>{title}</h1>
       </div>
      </>

     );
  }
  else if (role === "Manager") {
    return (
     <>
        <div className="header-center">
         <h1>{title}</h1>
       </div>
      </>

     );
  }
  else if (role === "Credit Customer") {
    return (
     <>
        <div className="header-center">
         <h1>{title}</h1>
       </div>
      </>

     );
  }
  else {
    return (
     <>
        <div className="header-center">
         <h1>{title}</h1>
       </div>
      </>

     );
  }
};

export { Header };
