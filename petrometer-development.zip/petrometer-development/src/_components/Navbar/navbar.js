import React, { Component } from "react";
import { authService } from "@S";
import { Link } from "react-router-dom";

class Navbar extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="nav-wrapper">
        <NavLinks role={authService.currentUserRole} />
        <div className="wave-container">
          <div className="wave"></div>
          <div className="wave"></div>
        </div>
      </div>
    );
  }
}

const NavLinks = ({ role }) => {
  if (role === "Site Admin") {
    return (
      <nav>
        <ul>
          <li>
            <Link to="/">Dashboard</Link>
          </li>
          <li>
            <Link to="account/admin/add/dealer">Create Dealer</Link>
          </li>
          <li>
            <Link to="account/admin/manage/subscription">
              Manage subscriptions
            </Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>
    );
  } else if (role === "Dealer") {
    return (
      <nav>
        <ul>
          <li>
            <Link to="/">Dashboard</Link>
          </li>
          <li>
            <Link to="/staff">Staff List</Link>
          </li>
          <li>
            <Link to="/account/dealer/setup/bunk">Bunk Setup</Link>
          </li>
          <li>
            <Link to="/reports">Reports</Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>
    );
  } else if (role === "Manager") {
    return (
      <nav>
        <ul>
          <li>
            <Link to="/">Dashboard</Link>
          </li>
          <li>
            <Link to="/credit-customers">Credit Customers</Link>
          </li>
          <li>
            <Link to="/dsr">DSR</Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>
    );
  } else if (role === "Credit Customer") {
    return (
      <nav>
        <ul>
          <li>
            <Link to="/">Dashboard</Link>
          </li>
          <li>
            <Link to="/vehicle">Vehicles</Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>
    );
  } else {
    return (
      <nav>
        <ul>
          <li>
            <Link to="/">Dashboard</Link>
          </li>
          <li>
            <Link to="/duty">Duty</Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>
    );
  }
};

export { Navbar };
