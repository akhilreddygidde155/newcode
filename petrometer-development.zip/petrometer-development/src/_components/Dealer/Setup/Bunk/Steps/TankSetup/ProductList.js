import React, { Component } from "react";
import Select from "react-select";
import services from "./data";

let CategoryOptions = [];

class ProductList extends Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

  }
  componentDidMount() {

    if (!CategoryOptions.length > 0) {

      services
        .getProductList()
        .then((response) => {

          let tmp = response.data.data;

          for (var i = 0; i < tmp.length; i++) {
            CategoryOptions.push({
              value: tmp[i].uuid,
              label: tmp[i].product,
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }
  handleChange = (selectedOption) => {
    let val = selectedOption.value;
    this.props.handleProductChange(selectedOption, this.props.did);
  };

  render() {
    return (
      <Select
        onChange={this.handleChange}
        options={CategoryOptions}
        classNamePrefix="raw-select"
        name="oml"
        placeholder="Select fuel"
        value={this.props.value}
      />
    );
  }
}

export default ProductList;
