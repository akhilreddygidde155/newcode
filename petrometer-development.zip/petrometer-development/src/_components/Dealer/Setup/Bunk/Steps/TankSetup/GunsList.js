import React, { Component, KeyboardEventHandler } from "react";

import CreatableSelect from "react-select/creatable";
import { ActionMeta, OnChangeValue } from "react-select";

const components = {
  DropdownIndicator: null,
};

const createKeywordOption = (label) => ({
  label,
  value: label,
});

export default class CreatableInputOnly extends Component {
  constructor(props) {
    super(props);

    this.state = {
      inputValue: "",
      value: [],
      list: []
    };
  }

  handleChange = (value) => {
    this.setState({ value: value, list: [] }, () => {
      for (let i = 0; i < value.length; i++) {
        this.setState((prevState) => ({
          list: [
            ...prevState.list,
            {name: value[i].value}
          ],
        }));
      }
    });
  };

  handleInputChange = (newValue) => {
    const inputValue = newValue;
    this.setState({ inputValue }, () => {
      this.props.handleGunChange(this.state.list, this.props.did);
    });
  };

  handleKeyDown = (event) => {
    const { inputValue, value } = this.state;

    if (!inputValue) return;

    switch (event.key) {
      case "Enter":
      case "Tab":
        if (value != null) {
          if (!this.state.value.find((x) => x.value === inputValue)) {
            this.setState({
              inputValue: "",
              value: [...value, createKeywordOption(inputValue)],
              list: [...this.state.list, {name: inputValue }],
            });
          }
        } else {
          this.setState({
            inputValue: "",
            value: [createKeywordOption(inputValue)],
            list: [{name: inputValue}],
          });
        }
        event.preventDefault();
        break;
      default:
    }
  };
  render() {
    const { inputValue, value } = this.state;
    return (
      <CreatableSelect
        components={components}
        inputValue={inputValue}
        isClearable
        isMulti
        menuIsOpen={false}
        onChange={this.handleChange}
        onInputChange={this.handleInputChange}
        onKeyDown={this.handleKeyDown}
        placeholder="Enter gun/nozzle"
        value={value}
        classNamePrefix="raw-select multi-value"
      />
    );
  }
}
