import React, { PureComponent } from "react";
import axios from "axios";
import { authHeader } from "@H";
import { authService } from "@S";
import { toast } from "react-toastify";
import services from "./dataWallets";
import BankList from "./BankList";

let tmp = [];
let tmp1 = [];

class WalletSetup extends PureComponent {
  state = {
    wallets: [],
    swipe_or_wallet_uuid: "",
    settlement_bank: "",
    settlement_bank_name: "Select Bank",
    logo: "",
    added: [],
  };

  componentDidMount() {
    if (!tmp.length > 0) {
      services
        .getAllWallets()
        .then((response) => {
          tmp = response.data.data;
          this.setState({ wallets: tmp });
        })
        .catch((error) => {
          console.log(error);
        });
      services
        .getMappedBanks()
        .then((response) => {
          tmp1 = response.data.data;
          this.setState({ banks: tmp1 });
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      this.setState({ banks: tmp1, wallets: tmp });
    }
  }

  handleBankChange = (e, f) => {
    this.setState({ settlement_bank: e, settlement_bank_name: f });
  };

  handleSubmit = (item) => {
    console.log(item);
    let walletData = [];
    walletData.push({
      swipe_or_wallet_uuid: item.uuid,
      settlement_options: "TODAY",
      settlement_bank: this.state.settlement_bank,
    });
    let tmp = this.state.swipe_or_wallet_uuid;
    let formData = {
      wallet_list: walletData,
    };
    let headers = authHeader(authService.currentAccountID);
    axios
      .post(`${process.env.API_URL}/bunk/map-wallets/`, formData, { headers })
      .then((response) => {
        if (response.status === 200) {
          toast.success("Wallet added successfully", {
            position: "bottom-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
          });
          this.setState({
            swipe_or_wallet_uuid: "",
            added: [...this.state.added, item.uuid]
          });
        } else {
          toast.error(response.data.message, {
            position: "bottom-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      });
  };

  render() {
    let { wallets, banks, added } = this.state;
    return (
      <div className="form-item">
        <div className="sub-wrapper">
          <div className="title">
            <h3>Add wallet</h3>
          </div>
          <div className="form-container --wallets">
            <div className="input-wrapper">
              <BankList
                id="settlement_bank"
                handleBankChange={this.handleBankChange}
                value={{
                  value: this.state.settlement_bank,
                  label: this.state.settlement_bank_name,
                }}
              />
            </div>
            <ul>
              {wallets.map((item, i) => {
                let w = item.uuid;
                let s = false;
                if (added.indexOf(w) !== -1) {
                  s = true;
                }
                return (
                  <li key={i}>
                    <div className="item-logo">
                      <img
                        src="https://1000logos.net/wp-content/uploads/2020/04/Google-Pay-Logo.png"
                        alt=""
                      />
                    </div>
                    <div className="item-title">
                      <h4>{item.bank_name}</h4>
                    </div>

                    <div className="sub-cta-wrapper">
                      {(() => {
                        if (s) {
                          return (
                            <button
                              onClick={() => this.handleSubmit(item)}
                              disabled={s}
                            >
                              Remove wallet
                            </button>
                          );
                        } else {
                          return (
                            <button
                              onClick={() => this.handleSubmit(item)}
                              disabled={s}
                            >
                              Add wallet
                            </button>
                          );
                        }
                      })()}
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    );
  }
}
export default WalletSetup;
