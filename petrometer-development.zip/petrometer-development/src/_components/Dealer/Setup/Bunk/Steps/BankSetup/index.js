import React, { Component } from "react";
import axios from "axios";
import { authHeader } from "@H";
import { authService } from "@S";
import BankList from "./BankList";
import BankAccountType from "./BankAccountType";
import { toast } from "react-toastify";

class BankSetup extends Component {
  state = {
    bankDetails: [
      {
        index: Math.random(),
        bank_uuid: "",
        account_type_uuid: "",
        bank_name:"",
        account_type_name: "",
      },
    ],
    idx: 0,
    bank_uuid: "",
    bank_name: "Select bank",
    account_type_uuid: "",
    account_type_name: "Select account type",
  };


  handleBankChange = (e, f) => {
    let bankDetails = [...this.state.bankDetails];
    bankDetails[f]["bank_uuid"] = e.value;
    bankDetails[f]["bank_name"] = e.label;
    this.setState({ bank_uuid: e.value, bank_name: e.label });
  };

  handleAccountTypeChange = (e, f) => {
    let bankDetails = [...this.state.bankDetails];
    bankDetails[f]["account_type_uuid"] = e.value;
    bankDetails[f]["account_type_name"] = e.label;
    this.setState({ account_type_uuid: e.value, account_type_name: e.label });
  };

  addItem = (e) => {
    e.preventDefault();
    this.setState((prevState) => ({
      bankDetails: [
        ...prevState.bankDetails,
        {
          index: Math.random(),
          bank_uuid: "",
          account_type_uuid: "",
          bank_name:"",
          account_type_name: "",
        },
      ],
      idx: this.state.idx + 1,
      bank_uuid: "",
      bank_name: "Select bank",
      account_type_uuid: "",
      account_type_name: "Select account type",
    }));
  };

  deleteItem = (index) => {
    this.setState({
      bankDetails: this.state.bankDetails.filter(
        (s, sindex) => index !== sindex
      ),
      idx: this.state.idx - 1,
    });
  };


  submitForm = () => {
    let bankData = this.state.bankDetails;
    bankData.pop();
    let formData = {
      banks_list: bankData,
      associate_account: authService.currentAccountID,
    };
    let headers = authHeader();

    axios
      .post(`${process.env.API_URL}/bunk/map-bank/`, formData, { headers })
      .then((response) => {
        console.log(response);
        toast.success("Banks added successfully", {
          position: "bottom-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
        });
      });
  };

  render() {
    let { bankDetails } = this.state;

    return (
      <>
        <div className="form-item">
          <div className="sub-wrapper">
            <div className="title">
              <h3>Add bank details</h3>
            </div>
            <div className="form-container">
              <form>
                <div className="input-wrapper">
                  <BankList
                    did={this.state.idx}
                    id="product_uuid"
                    handleBankChange={this.handleBankChange}
                    value={ {value: this.state.bank_uuid,
                              label: this.state.bank_name}}
                  />
                </div>
                <div className="input-wrapper">
                  <BankAccountType
                    did={this.state.idx}
                    id="product_uuid"
                    handleAccTypeChange={this.handleAccountTypeChange}
                    value={ {value: this.state.account_type_uuid,
                              label: this.state.account_type_name}}
                  />
                </div>
                <div className="cta-wrapper">
                  <button onClick={this.addItem}>Add</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="item-list-wrapper">
          <div className="sub-wrapper">
            <div className="title">
              <h3>Account List</h3>
            </div>
            <div className="item-list">
              <ul>
                {bankDetails.map((item, i) => {
                  if (i < bankDetails.length - 1) {
                    return (
                      <li key={i}>
                        <div className="item-iamge">
                          <img src={item.logo} />
                        </div>
                        <div className="item-title">
                          <h4>{item.bank_name}</h4>
                        </div>
                        <div className="item-info">
                          <span>{item.account_type_name}</span>
                        </div>
                        <div className="item-actions">
                          <button
                            className="delete-item"
                            onClick={() => this.deleteItem(i)}
                          >
                            Delete
                          </button>
                        </div>
                      </li>
                    );
                  }
                })}
              </ul>
            </div>
            <div className="cta-wrapper">
              <button type="submit" onClick={this.submitForm}>
                Submit
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default BankSetup;
