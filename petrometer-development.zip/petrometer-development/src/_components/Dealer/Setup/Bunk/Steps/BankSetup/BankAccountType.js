import React, { Component } from "react";
import Select from "react-select";
import services from "./dataType";

let CategoryOptions = [];

class BankAccountType extends Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

  }
  componentDidMount() {

    if (!CategoryOptions.length > 0) {

      services
        .getAccountTypeList()
        .then((response) => {

          let tmp = response.data.data;

          for (var i = 0; i < tmp.length; i++) {
            CategoryOptions.push({
              value: tmp[i].uuid,
              label: tmp[i].account_type,

            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }
  handleChange = (selectedOption) => {
    let val = selectedOption.value;
    this.props.handleAccTypeChange(selectedOption, this.props.did);
  };

  render() {
    return (
      <Select
        onChange={this.handleChange}
        options={CategoryOptions}
        classNamePrefix="raw-select"
        name="bank"
        placeholder="Select account type"
        value={this.props.value}
      />
    );
  }
}

export default BankAccountType;
