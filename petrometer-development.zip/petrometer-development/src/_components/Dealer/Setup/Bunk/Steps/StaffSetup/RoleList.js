import React, { Component } from "react";
import Select from "react-select";
import services from "./data";

let CategoryOptions = [
  {
    value: 103,
    label: 'Cashier'
  },
  {
    value: 102,
    label: 'Manager'
  }
];

class RoleList extends Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

  }
  componentDidMount() {

  }
  handleChange = (selectedOption) => {
    let val = selectedOption.value;
    this.props.handleRoleChange(val);
  };

  render() {
    return (
      <Select
        onChange={this.handleChange}
        options={CategoryOptions}
        classNamePrefix="raw-select"
        name="oml"
        placeholder="Select role"
      />
    );
  }
}

export default RoleList;
