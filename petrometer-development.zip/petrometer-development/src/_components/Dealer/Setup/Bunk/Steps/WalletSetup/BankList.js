import React, { Component } from "react";
import Select from "react-select";
import services from "./dataWallets";


let CategoryOptions;
class BankList extends Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

  }
  componentDidMount() {
    CategoryOptions = [];
      services
        .getMappedBanks()
        .then((response) => {

          let tmp = response.data.data;

          for (var i = 0; i < tmp.length; i++) {
            CategoryOptions.push({
              value: tmp[i].uuid,
              label: tmp[i].bank_name,
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });

  }
  handleChange = (selectedOption) => {
    let val = selectedOption.value;
    this.props.handleBankChange(val, selectedOption.label);
  };

  render() {
    return (
      <Select
        onChange={this.handleChange}
        options={CategoryOptions}
        classNamePrefix="raw-select"
        name="bank"
        placeholder="Select bank"
        value={this.props.value}
      />
    );
  }
}

export default BankList;
