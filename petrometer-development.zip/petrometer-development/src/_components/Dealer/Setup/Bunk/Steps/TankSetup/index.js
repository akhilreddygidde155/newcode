import React, { Component } from "react";
import axios from "axios";
import { authHeader } from "@H";
import { authService } from "@S";
import ProductList from "./ProductList";
import { ToggleSwitch } from "@C/FormElements";
import SimpleReactValidator from "simple-react-validator";
import { toast } from "react-toastify";

class TankSetup extends Component {
  constructor() {
    super();
    this.validator = new SimpleReactValidator({
      autoForceUpdate: this,
      element: (message) => <div className="input-error">{message}</div>,
    });
  }

  state = {
    tankDetails: [
      {
        index: Math.random(),
        name: "",
        product_uuid: "",
        product_name: "",
        capacity: "",
        price: 1,
        dip_reading: 0,
        number_of_guns: "",
        gun_list: [],
        is_bowser: false,
      },
    ],
    idx: 0,
    name: "",
    capacity: "",
    product_name: "Select Fuel",
    product_uuid: "",
    number_of_guns: "",
    is_bowser: false,
  };

  handleChange = (e, f) => {
    if (["is_bowser"].includes(e.target.name)) {
      let tankDetails = [...this.state.tankDetails];
      tankDetails[e.target.dataset.id][e.target.name] = e.target.checked;
      this.setState({ [e.target.name]: e.target.checked });
    } else {
      let tankDetails = [...this.state.tankDetails];
      tankDetails[e.target.dataset.id][e.target.name] = e.target.value;
      this.setState({ [e.target.name]: e.target.value });
    }
  };

  handleProductChange = (e, f) => {
    let tankDetails = [...this.state.tankDetails];
    tankDetails[f]["product_uuid"] = e.value;
    tankDetails[f]["product_name"] = e.label;
    this.setState({ product_uuid: e.value, product_name: e.label });
  };

  handleGunList = (e) => {
    let g = [];

    for (let i = 0; i < e.target.value; i++) {
      g[i] = { name: `Gun ${i + 1}` };
    }
    let tankDetails = [...this.state.tankDetails];
    tankDetails[e.target.dataset.id]["gun_list"] = g;
    tankDetails[e.target.dataset.id]["number_of_guns"] = e.target.value;
    this.setState({ number_of_guns: e.target.value });
  };

  addItem = (e) => {
    e.preventDefault();
    if (this.validator.allValid()) {
      this.validator.hideMessages();
      this.setState((prevState) => ({
        tankDetails: [
          ...prevState.tankDetails,
          {
            index: Math.random(),
            name: "",
            product_uuid: "",
            product_name: "",
            capacity: "",
            price: 1,
            dip_reading: 0,
            number_of_guns: "",
            gun_list: [],
            is_bowser: false,
          },
        ],
        idx: this.state.idx + 1,
        name: "",
        capacity: "",
        number_of_guns: "",
        product_name: "Select Fuel",
        product_uuid: "",
        is_bowser: false,
      }));
    } else {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
  };

  deleteItem = (index) => {
    this.setState({
      tankDetails: this.state.tankDetails.filter(
        (s, sindex) => index !== sindex
      ),
      idx: this.state.idx - 1,
    });
  };

  submitForm = () => {
    let tankData = this.state.tankDetails;
    tankData.pop();
    let formData = {
      tanks: tankData,
      associate_account: authService.currentAccountID,
    };
    console.log(formData);
    let headers = authHeader();
    axios
      .post(`${process.env.API_URL}/bunk/tank-mapping/`, formData, { headers })
      .then((response) => {
        console.log(response);
        toast.success("Tanks added successfully", {
          position: "bottom-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
        });
      });
  };

  render() {
    let { tankDetails } = this.state;

    return (
      <>
        <div className="form-item">
          <div className="sub-wrapper">
            <div className="title">
              <h3>Add new tank</h3>
            </div>
            <div className="form-container">
              <form>
                <div className="input-wrapper">
                  {this.validator.message(
                    "name",
                    this.state.name,
                    "required|alpha_num_dash_space"
                  )}
                  <input
                    type="text"
                    placeholder="Name"
                    data-id={this.state.idx}
                    id="name"
                    name="name"
                    onChange={this.handleChange}
                    value={this.state.name}
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "capacity",
                    this.state.capacity,
                    "required|integer|min:1",
                    { messages: { integer: "The capacity must be a number.", min: "The minimum capacity should be atleast 1" } }
                  )}
                  <input
                    type="text"
                    placeholder="Capacity"
                    data-id={this.state.idx}
                    id="capacity"
                    name="capacity"
                    onChange={this.handleChange}
                    value={this.state.capacity}
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "product_uuid",
                    this.state.product_uuid,
                    "required",
                    { messages: { required: "Please select a fuel" } }
                  )}
                  <ProductList
                    did={this.state.idx}
                    id="product_uuid"
                    handleProductChange={this.handleProductChange}
                    value={{
                      value: this.state.product_uuid,
                      label: this.state.product_name,
                    }}
                  />
                </div>
                <div className="input-wrapper">
                {this.validator.message(
                    "number_of_guns",
                    this.state.number_of_guns,
                    "required|numeric|min:1,num",
                    { messages: { required: "Please enter the number of guns", min: "The minimum number of gun should be atleast 1" } }
                  )}
                  <input
                    type="number"
                    placeholder="Nof of guns/nozzles"
                    data-id={this.state.idx}
                    id="guns"
                    name="guns"
                    onChange={this.handleGunList}
                    value={this.state.number_of_guns}

                  />
                </div>
                <div className="input-wrapper toggle-element">
                  <span> Is bowser: </span>
                  <ToggleSwitch
                    did={this.state.idx}
                    id="is_bowser"
                    name="is_bowser"
                    checked={this.state.is_bowser}
                    onChange={this.handleChange}
                  />
                </div>

                <div className="cta-wrapper">
                  <button onClick={this.addItem}>Add</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="item-list-wrapper">
          <div className="sub-wrapper">
            <div className="title">
              <h3>Tank List</h3>
            </div>
            <div className="item-list">
              <ul>
                {tankDetails.map((item, i) => {
                  if (i < tankDetails.length - 1) {
                    return (
                      <li key={i}>
                        <div className="item-title">
                          <h4>{item.name}</h4>
                        </div>
                        <div className="item-info">
                          <span>{item.product_name}</span>
                          <span>{item.capacity}</span>
                          <span>{item.number_of_guns}</span>
                          <span>Is bowser: {item.is_bowser.toString()}</span>
                        </div>
                        <div className="item-actions">
                          <button
                            className="delete-item"
                            onClick={() => this.deleteItem(i)}
                          >
                            Delete
                          </button>
                        </div>
                      </li>
                    );
                  }
                })}
              </ul>
            </div>
            <div className="cta-wrapper">
              <button type="submit" onClick={this.submitForm}>
                Submit
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default TankSetup;
