import React, { Component } from "react";
import axios from "axios";
import { authHeader } from "@H";
import { authService } from "@S";
import RoleList from "./RoleList";
import { toast } from "react-toastify";
import SimpleReactValidator from "simple-react-validator";

class StaffSetup extends Component {
  constructor() {
    super();
    this.validator = new SimpleReactValidator({
      autoForceUpdate: this,
      element: (message) => <div className="input-error">{message}</div>,
    });
  }

  state = {
    username: "",
    password: "",
    email: "",
    mobile: "",
    user_role: "",
    first_name: "",
    last_name: "",
  };

  handleChange = (e) => {
    if (["name", "capacity"].includes(e.target.name)) {
      let staffDetails = [...this.state.staffDetails];
      staffDetails[e.target.dataset.id][e.target.name] = e.target.value;
      this.setState({ [e.target.name]: e.target.value });
    } else {
      this.setState({ [e.target.name]: e.target.value });
    }
  };

  handleRoleChange = (e) => {
    console.log(e);
    this.setState({ user_role: e });
  };

  continue = (e) => {
    e.preventDefault();
    this.props.nextStep();
  };

  back = (e) => {
    e.preventDefault();
    this.props.prevStep();
  };

  submitForm = () => {
    if (this.validator.allValid()) {
      let formData = {
        username: this.state.username,
        password: this.state.password,
        email: this.state.email,
        mobile: this.state.mobile,
        user_role: this.state.user_role,
        first_name: this.state.first_name,
        last_name: this.state.last_name,
      };

      let headers = authHeader(authService.currentAccountID);

      axios
        .post(`${process.env.API_URL}/users/register/`, formData, { headers })
        .then((response) => {
          console.log(response);
          if (response.status === 201) {
            toast.success("Staff added successfully", {
              position: "bottom-center",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
            });
            this.setState({
              first_name: "",
              last_name: "",
              email: "",
              mobile: "",
              username: "",
              password: "",
              user_role: "",
            });
          } else {
            toast.error(response.data.message, {
              position: "bottom-center",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        });
    } else {
      this.validator.showMessages();
      this.forceUpdate();
      return;
    }
  };

  render() {
    return (
      <>
        <div className="form-item">
          <div className="sub-wrapper">
            <div className="title">
              <h3>Add staff</h3>
            </div>
            <div className="form-container">
              <form>
                <div className="input-wrapper">
                  {this.validator.message(
                    "first name",
                    this.state.first_name,
                    "required|alpha"
                  )}
                  <input
                    type="text"
                    placeholder="First Name"
                    id="fname"
                    name="first_name"
                    onChange={this.handleChange}
                    value={this.state.first_name}
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "last name",
                    this.state.last_name,
                    "required|alpha"
                  )}
                  <input
                    type="text"
                    placeholder="Last Name"
                    id="lname"
                    name="last_name"
                    onChange={this.handleChange}
                    value={this.state.last_name}
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "email",
                    this.state.email,
                    "required|email"
                  )}
                  <input
                    type="text"
                    placeholder="Email"
                    id="email"
                    name="email"
                    onChange={this.handleChange}
                    value={this.state.email}
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "username",
                    this.state.username,
                    "required|alpha_num_dash_space"
                  )}
                  <input
                    type="text"
                    placeholder="Username"
                    id="username"
                    name="username"
                    onChange={this.handleChange}
                    value={this.state.username}
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "password",
                    this.state.password,
                    "required"
                  )}
                  <input
                    type="password"
                    placeholder="Password"
                    onChange={this.handleChange}
                    value={this.state.password}
                    id="password"
                    name="password"
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "mobile",
                    this.state.mobile,
                    "required|phone"
                  )}
                  <input
                    type="text"
                    placeholder="Mobile"
                    id="mobile"
                    name="mobile"
                    onChange={this.handleChange}
                    value={this.state.mobile}
                  />
                </div>
                <div className="input-wrapper">
                  {this.validator.message(
                    "role",
                    this.state.user_role,
                    "required",
                    { messages: { required: "Please select a role" } }
                  )}
                  <RoleList
                    did={this.state.idx}
                    id="user_role"
                    handleRoleChange={this.handleRoleChange}
                  />
                </div>
              </form>
              <div className="cta-wrapper">
                <button onClick={this.submitForm}>Register</button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default StaffSetup;
