import axios from 'axios';
import { authHeader } from '@H';
import { authService } from '@S';

export default {
    getAllWallets: () =>
    axios({
        'method':'GET',
        'headers': authHeader(),
        'url':`${process.env.API_URL}/utils/wallets/`,

    }),
    getMappedBanks: () =>
    axios({
        'method':'GET',
        'headers': authHeader(authService.currentAccountID),
        'url':`${process.env.API_URL}/bunk/map-bank/`,

    }),

}
