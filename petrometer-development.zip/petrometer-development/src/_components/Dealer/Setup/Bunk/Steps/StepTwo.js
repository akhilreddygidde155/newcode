import React, { Component } from "react";

export class StepTwo extends Component {
  continue = (e) => {
    e.preventDefault();
    this.props.nextStep();
  };

  back = (e) => {
    e.preventDefault();
    this.props.prevStep();
  };

  render() {
    const { values, handleChange } = this.props;
    return (
      <>
        <div className="form-item">
          <div className="input-wrapper">
            <h2>Step 2</h2>
            <div className="cta-wrapper">
              <button onClick={this.back}>Go Back</button>
              <button onClick={this.continue}>Continue</button>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default StepTwo;
