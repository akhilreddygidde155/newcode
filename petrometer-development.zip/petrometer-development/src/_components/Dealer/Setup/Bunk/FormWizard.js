import React, { Component } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { authHeader } from "@H";
import { authService } from "@S";
import TankSetup from "./Steps/TankSetup";
import WalletSetup from "./Steps/WalletSetup";
import BankSetup from "./Steps/BankSetup";
import StaffSetup from "./Steps/StaffSetup";

export class FormWizard extends Component {
  state = {
    error: false,
    step: 1,
  };

  toggleStep = (e) => {
    const { step } = this.state;
    if (step !== e) this.setState({ step: e });
  };


  render() {
    const { step } = this.state;

    return (
      <div className="step-form-container">
        <div className="inner-wrapper">
          <div className="steps-list">
            <ul>
              <li className={`${step === 1 ? "active" : ""}`}>
                <button
                  className="toggle-step"
                  onClick={() => this.toggleStep(1)}
                >
                  Tank Details
                </button>
              </li>
              <li className={`${step === 2 ? "active" : ""}`}>
                <button
                  className="toggle-step"
                  onClick={() => this.toggleStep(2)}
                >
                  Bank Details
                </button>
              </li>
              <li className={`${step === 3 ? "active" : ""}`}>
                <button
                  className="toggle-step"
                  onClick={() => this.toggleStep(3)}
                >
                  Wallet Details
                </button>
              </li>
              <li className={`${step === 4 ? "active" : ""}`}>
                <button
                  className="toggle-step"
                  onClick={() => this.toggleStep(4)}
                >
                  Staff Details
                </button>
              </li>
            </ul>
          </div>
          <div className="form-wrapper">
            {(() => {
              switch (step) {
                case 1:
                  return <TankSetup />;
                case 2:
                  return <BankSetup />;
                case 3:
                  return <WalletSetup />;
                case 4:
                  return <StaffSetup />;
                default:
                  console.log("PetroMeter");
              }
            })()}
          </div>
        </div>
      </div>
    );
  }
}

export default FormWizard;
