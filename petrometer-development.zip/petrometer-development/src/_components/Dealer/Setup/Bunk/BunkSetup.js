import React, { Component } from 'react';
import { Navbar, Header } from '@C/Navbar'
import { FormWizard } from '@C/Dealer/Setup/Bunk';

class BunkSetup extends Component {
    constructor(props) {
        super(props);


    }

    componentDidMount() {

    }

    render() {
       
        return (
            <div className="page-wrapper">
              <Header title="Bunk Setup" />
                <main>
                 <Navbar />
                 <div className="main-container">
                 <div className="main-wrapper">
                   <FormWizard />
                   </div>
                 </div>
                </main>
            </div>
        );
    }
}

export { BunkSetup };
