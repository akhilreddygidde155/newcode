import React, { Component } from 'react';

class CashierDashboard extends Component {
    constructor(props) {
        super(props);

        this.state = {
          title: this.props.title
        }
    }

    componentDidMount() {
        
    }

    render() {
       
         return (
            <div className="page-wrapper">
              <Header title={this.state.title} />
                <main>
                 <Navbar />
                 <div className="main-container">
                 <div className="main-wrapper">
                   <h1>Something</h1>
                   </div>
                 </div>
                </main>
            </div>
        );
    }
}

export { CashierDashboard };
