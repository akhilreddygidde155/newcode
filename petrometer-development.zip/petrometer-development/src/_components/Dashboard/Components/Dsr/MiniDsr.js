import React, { Component } from "react";
import { authService } from "@S";
import DateTimePicker from "react-datetime-picker";
import {
  PieChart,
  Pie,
  Cell,
  Legend,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import services from "./data";

const data = [
  { name: "Petrol", value: 20000 },
  { name: "Diesel", value: 8678 },
  { name: "V-Power", value: 9539 },
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

class MiniDsr extends Component {
  constructor() {
    super();
    this.state = {
      time: new Date(),
      chartData: [],
    };
  }

  componentDidMount() {
    services
      .getStaffList()
      .then((response) => {})
      .catch((error) => {
        console.log(error);
      });
  }

  changeDate = (value) => {
    this.setState({ time: value })
  }

  render() {
    return (
      <>
        <div className="component-wrapper --mini-dsr">
          <div className="inner-wrapper">
            <div className="title-wrapper">
              <h3>DSR</h3>
            </div>
            <div className="content-wrapper">
              <div className="date-wrapper">
                <DateTimePicker
                  value={this.state.time}
                  format="h:mm a MMM d, yyyy"
                  calendarIcon="cstm-calendar"
                  clearIcon={null}
                  onChange={this.changeDate}
                />
              </div>
              <div className="items-container">
                Some data
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export { MiniDsr };
