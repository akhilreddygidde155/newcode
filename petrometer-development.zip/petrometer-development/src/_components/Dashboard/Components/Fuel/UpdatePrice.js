import React, { Component } from "react";
import { authService } from "@S";
import DateTimePicker from 'react-datetime-picker';



class UpdatePrice extends Component {

  constructor () {
    super()
    this.state = {
      time: new Date()
    }
  }



  componentDidMount () {

  }

  changeDate = (value) => {
    this.setState({ time: value })
  }


  render () {


    return(
      <>

          <div className="component-wrapper --fuel-price">
            <div className="inner-wrapper">
              <div className="title-wrapper">
                <h3>Fuel Price</h3>
              </div>
              <div className="content-wrapper">
                <div className="date-wrapper">
                <DateTimePicker
                value={this.state.time}
                format="h:mm a MMM d, yyyy"
                calendarIcon="cstm-calendar"
                clearIcon={null}
                onChange={this.changeDate}
                  />

                </div>
                <div className="items-container">
                  <div className="component-item">
                    <div className="item-title">
                      <h4>Petrol</h4>
                    </div>
                    <div className="item-price">
                      <input type="text" name="price" disabled value="100.10" />
                    </div>
                    <div className="item-actions">
                      <button className="edit">Edit Price</button>
                    </div>
                  </div>
                  <div className="component-item">
                    <div className="item-title">
                      <h4>Diesel</h4>
                    </div>
                    <div className="item-price">
                      <input type="text" name="price" disabled value="90.10" />
                    </div>
                    <div className="item-actions">
                      <button className="edit">Edit Price</button>
                    </div>
                  </div>
                  <div className="component-item">
                    <div className="item-title">
                      <h4>V-Power</h4>
                    </div>
                    <div className="item-price">
                      <input type="text" name="price" disabled value="120.10" />
                    </div>
                    <div className="item-actions">
                      <button className="edit">Edit Price</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

      </>
      );
  }
}

export { UpdatePrice };
