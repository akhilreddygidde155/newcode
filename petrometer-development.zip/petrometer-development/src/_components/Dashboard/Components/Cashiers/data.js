import axios from 'axios';
import { authHeader } from '@H';

export default {
    getStaffList: () =>
    axios({
        'method':'GET',
        'headers': authHeader(1),
        'url':`${process.env.API_URL}/bunk/staff/associate-staff/`,

    }),

}
