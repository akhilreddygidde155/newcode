import React, { Component } from "react";
import { authService } from "@S";
import DateTimePicker from "react-datetime-picker";
import services from "./data";

class AssignDuty extends Component {
  constructor() {
    super();
    this.state = {
      time: new Date(),
    };
  }

  componentDidMount() {
    services
      .getStaffList()
      .then((response) => {

      })
      .catch((error) => {
        console.log(error);
      });
  }

  changeDate = (value) => {
    this.setState({ time: value })
  }

  render() {
    return (
      <>
        <div className="component-wrapper --assign-duty">
          <div className="inner-wrapper">
            <div className="title-wrapper">
              <h3>Cashiers on Duty</h3>
            </div>
            <div className="content-wrapper">
              <div className="date-wrapper">
                <DateTimePicker
                  value={this.state.time}
                  format="h:mm a MMM d, yyyy"
                  calendarIcon="cstm-calendar"
                  clearIcon={null}
                  onChange={this.changeDate}
                />
              </div>
              <div className="items-container"></div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export { AssignDuty };
