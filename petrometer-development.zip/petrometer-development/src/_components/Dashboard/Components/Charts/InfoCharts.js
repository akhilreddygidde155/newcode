import React, { Component } from "react";
import { authService } from "@S";
import DateTimePicker from "react-datetime-picker";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend,
  Tooltip,
  ResponsiveContainer,
  Sector,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import services from "./data";

const data = [
  { name: "Petrol", sales: 20000 },
  { name: "Diesel", sales: 8678 },
  { name: "V-Power", sales: 9539 },
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];
const RADIAN = Math.PI / 180;

class InfoCharts extends Component {
  constructor() {
    super();
    this.state = {
      time: new Date(),
      chartData: [],
      activeIndex: 0,
      chartType: 1,
    };
  }

  onPieEnter = (_, index) => {
    this.setState({
      activeIndex: index,
    });
  };

  componentDidMount() {
    services
      .getStaffList()
      .then((response) => {})
      .catch((error) => {
        console.log(error);
      });
  }

  changeDate = (value) => {
    this.setState({ time: value });
  };

  changeChartType = (value) => {
    this.setState({ chartType: value });
  };

  render() {
    const { chartType } = this.state;

    return (
      <>
        <div className="component-wrapper --mini-dsr">
          <div className="inner-wrapper">
            <div className="title-wrapper">
              <h3>Charts</h3>
            </div>
            <div className="content-wrapper">
              <div className="date-wrapper --half">
                <div className="picker-wrapper">
                  <DateTimePicker
                    value={this.state.time}
                    format="h:mm a MMM d, yyyy"
                    calendarIcon="cstm-calendar"
                    clearIcon={null}
                    onChange={this.changeDate}
                  />
                </div>
                <div className="chart-type-wrapper">
                  <ul>
                    <li>
                      <button
                        className="pie"
                        onClick={() => this.changeChartType(1)}
                      >
                        Pie Chart
                      </button>
                    </li>
                    <li>
                      <button
                        className="bar"
                        onClick={() => this.changeChartType(2)}
                      >
                        Bar Chart
                      </button>
                    </li>
                    <li>
                      <button
                        className="line"
                        onClick={() => this.changeChartType(3)}
                      >
                        Line Chart
                      </button>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="items-container">
                <div
                  className="chart-wrapper"
                  style={{ width: "100%", height: 400 }}
                >
                  <h5>Total sales / Fuel</h5>
                  {(() => {
                    switch (chartType) {
                      case 1:
                        return <ChartPie />;
                      case 2:
                        return <ChartBar />;
                      case 3:
                        return <ChartLine />;
                      default:
                        console.log("PetroMeter");
                    }
                  })()}
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

class ChartPie extends Component {
  constructor() {
    super();
    this.state = {
      time: new Date(),
      chartData: [],
      activeIndex: 0,
      chartType: 1,
    };
  }

  onPieEnter = (_, index) => {
    this.setState({
      activeIndex: index,
    });
  };

  render() {
    return (
      <ResponsiveContainer>
        <PieChart>
          <Pie
            isAnimationActive={false}
            dataKey="sales"
            data={data}
            innerRadius={80}
            activeShape={renderActiveShape}
            activeIndex={this.state.activeIndex}
            onMouseEnter={this.onPieEnter}
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
    );
  }
}

class ChartBar extends Component {
  constructor() {
    super();
    this.state = {
      chartData: [],
      chartType: 1,
    };
  }

  render() {
    return (
      <ResponsiveContainer>
        <BarChart
          width={500}
          height={300}
          data={data}
          isAnimationActive={false}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="sales" isAnimationActive={false}>
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    );
  }
}

class ChartLine extends Component {
  constructor() {
    super();
    this.state = {
      chartData: [],
      chartType: 1,
    };
  }

  render() {
    return (
      <ResponsiveContainer>
        <LineChart
          width={500}
          height={300}
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line
            type="monotone"
            dataKey="sales"
            stroke="#004474"
            isAnimationActive={false}
            dot={<CustomizedDot />}
          />
        </LineChart>
      </ResponsiveContainer>
    );
  }
}

const CustomizedDot = (props) => {
  const { cx, cy, stroke, payload, value } = props;
  const name = props.payload.name;


  switch (name) {
    case "Petrol":
      return (
        <svg x={cx - 4} y={cy - 4} width={8} height={8} fill="blue">
          <g transform="translate(4 4)">
            <circle r="4" fill="blue" />
            <circle r="2" fill="blue" />
          </g>
        </svg>
      );
    case "Diesel":
      return (
        <svg x={cx - 4} y={cy - 4} width={8} height={8} fill="green">
          <g transform="translate(4 4)">
            <circle r="4" fill="green" />
            <circle r="2" fill="green" />
          </g>
        </svg>
      );
    case "V-Power":
      return (
        <svg x={cx - 4} y={cy - 4} width={8} height={8} fill="yellow">
          <g transform="translate(4 4)">
            <circle r="4" fill="yellow" />
            <circle r="2" fill="yellow" />
          </g>
        </svg>
      );
    default:
      return (
        <svg x={cx - 4} y={cy - 4} width={8} height={8} fill="yellow">
          <g transform="translate(4 4)">
            <circle r="4" fill="yellow" />
            <circle r="2" fill="yellow" />
          </g>
        </svg>
      );
  }
};

const renderActiveShape = (props) => {
  const RADIAN = Math.PI / 180;
  const {
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    fill,
    payload,
    percent,
    value,
  } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * sin;
  const mx = cx + (outerRadius + 30) * cos;
  const my = cy + (outerRadius + 30) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 22;
  const ey = my;
  const textAnchor = cos >= 0 ? "start" : "end";

  return (
    <g>
      <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill} font-weight="bold">
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path
        d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`}
        stroke={fill}
        fill="none"
      />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text
        x={ex + (cos >= 0 ? 1 : -1) * 12}
        y={ey}
        dy={18}
        textAnchor={textAnchor}
        fill="#999"
      >
        {`Total sales`}
      </text>
      <text
        x={ex + (cos >= 0 ? 1 : -1) * 12}
        y={ey}
        textAnchor={textAnchor}
        fill="#004474"
      >{`${value} L`}</text>
    </g>
  );
};

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${label} : ${payload[0].value}`}</p>
        <p className="desc">Anything you want can be displayed here.</p>
      </div>
    );
  }

  return null;
};

export { InfoCharts };
