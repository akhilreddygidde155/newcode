import React, { Component } from "react";
import { Navbar, Header } from "@C/Navbar";
import { UpdatePrice, AssignDuty, MiniDsr, InfoCharts } from "@C/Dashboard/Components";


class ManagerDashboard extends Component {
  constructor(props) {
    super(props);

    this.state = {
      title: this.props.title,
    };
  }

  componentDidMount() {}

  render() {
    return (
      <div className="page-wrapper">
        <Header title={this.state.title} />
        <main>
          <Navbar />
          <div className="main-container">
            <div className="main-wrapper">
              <div className="components-container">
                <UpdatePrice />
                <AssignDuty />
                <MiniDsr />
                <InfoCharts />
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export { ManagerDashboard };
