import React, { Component } from "react";

export class StepOne extends Component {
  continue = (e) => {
    e.preventDefault();
    this.props.nextStep();
  };

  back = (e) => {
    e.preventDefault();
    this.props.prevStep();
  };

  render() {
    const { values, handleChange } = this.props;
    return (
      <>
        <div className="form-item">
          <div className="sub-wrapper">
            <div className="title">
              <h3>Add dealer details</h3>
            </div>
            <div className="form-container">
              <form>
                <div
                  className={
                    this.props.error
                      ? "error-wrapper --display"
                      : "error-wrapper"
                  }
                >
                  <p>Please fill all the fields and try again</p>
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="First name"
                    onChange={handleChange("fName")}
                    value={values.fName}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="Last name"
                    onChange={handleChange("lName")}
                    value={values.lName}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="email"
                    placeholder="E-mail"
                    onChange={handleChange("email")}
                    value={values.email}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="number"
                    placeholder="Mobile"
                    onChange={handleChange("mobile")}
                    value={values.mobile}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="Username"
                    onChange={handleChange("userName")}
                    value={values.userName}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="password"
                    placeholder="Password"
                    onChange={handleChange("password")}
                    value={values.password}
                  />
                </div>
                <div className="cta-wrapper">
                  <button onClick={this.continue}>Continue</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default StepOne;
