import axios from 'axios';
import { authHeader } from '@H';

export default {
    getOMCList: () =>
    axios({
        'method':'GET',
        'headers': authHeader(),
        'url':`${process.env.API_URL}/bunk/omc/omc-list`,

    }),

}
