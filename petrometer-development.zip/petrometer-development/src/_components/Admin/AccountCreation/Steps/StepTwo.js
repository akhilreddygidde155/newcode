import React, { Component } from "react";
import OMCList from "./OMCList";

export class StepTwo extends Component {
  continue = (e) => {
    e.preventDefault();
    this.props.nextStep();
  };

  back = (e) => {
    e.preventDefault();
    this.props.prevStep();
  };

  submitForm = (e) => {
    e.preventDefault();
    this.props.submitData();
  };

  handleOMCChange = (e) => {
    this.props.handleSelectChange(e);
  };

  render() {
    const { values, handleChange } = this.props;
    return (
      <>
        <div className="form-item">
          <div className="sub-wrapper">
            <div className="title">
              <h3>Add bunk details</h3>
            </div>
            <div className="form-container">
              <form>
                <div
                  className={
                    this.props.error
                      ? "error-wrapper --display"
                      : "error-wrapper"
                  }
                >
                  <p>Please fill all the fields and try again</p>
                </div>
                <div className="input-wrapper">
                  <OMCList handleOMCChange={this.handleOMCChange} />
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="Bunk Name"
                    onChange={handleChange("bunkName")}
                    value={values.bunkName}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="City"
                    onChange={handleChange("city")}
                    value={values.city}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="State"
                    onChange={handleChange("location")}
                    value={values.location}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="Country"
                    onChange={handleChange("country")}
                    value={values.country}
                  />
                </div>
                <div className="input-wrapper">
                  <input
                    type="text"
                    placeholder="Pincode"
                    onChange={handleChange("pincode")}
                    value={values.pincode}
                  />
                </div>
                <div className="cta-wrapper">
                  <button onClick={this.back}>Go Back</button>
                  <button onClick={this.submitForm}>Register</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default StepTwo;
