import React, { Component } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { authHeader } from "@H";

import StepOne from "./Steps/StepOne";
import StepTwo from "./Steps/StepTwo";

export class FormWizard extends Component {
  state = {
    error: false,
    step: 1,
    fName: "",
    lName: "",
    email: "",
    mobile: "",
    userName: "",
    password: "",
    omc: "",
    bunkName: "",
    city: "",
    location: "",
    country: "",
    pincode: "",
    subscription: 200,
    role: 101,
  };

  nextStep = () => {
    const { step } = this.state;
    this.setState({
      step: step + 1,
    });
  };

  prevStep = () => {
    const { step } = this.state;
    this.setState({
      step: step - 1,
    });
  };

  toggleStep = (e) => {
    const { step } = this.state;
    if (step !== e) this.setState({ step: e });
  };

  handleChange = (input) => (e) => {
    this.setState({ [input]: e.target.value });
  };

  handleSelectChange = (e) => {
    this.setState({ omc: e });
  };

  submitData = () => {
    if (
      !this.state.userName ||
      !this.state.password ||
      !this.state.email ||
      !this.state.mobile ||
      !this.state.fName ||
      !this.state.lName ||
      !this.state.bunkName ||
      !this.state.city ||
      !this.state.location ||
      !this.state.country ||
      !this.state.pincode ||
      !this.state.omc
    ) {
      this.setState({ error: true });

      return false;
    } else {
      this.setState({ error: false });
    }

    let formData = {
      username: this.state.userName,
      password: this.state.password,
      email: this.state.email,
      mobile: this.state.mobile,
      user_role: this.state.role,
      first_name: this.state.fName,
      last_name: this.state.lName,
      subscription: {
        plan_code: this.state.subscription,
        bunk: {
          ro_name: this.state.bunkName,
          omc_uuid: this.state.omc,
          address: {
            city: this.state.city,
            state: this.state.location,
            country: this.state.country,
            pincode: this.state.pincode,
          },
        },
      },
    };

    let headers = authHeader();

    axios
      .post(`${process.env.API_URL}/users/register/`, formData, { headers })
      .then((response) => {
        toast.success("Account created successfully", {
          position: "bottom-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        this.setState({
          error: false,
          step: 1,
          fName: "",
          lName: "",
          email: "",
          mobile: "",
          userName: "",
          password: "",
          omc: "",
          bunkName: "",
          city: "",
          location: "",
          country: "",
          pincode: "",
          subscription: 200,
          role: 101,
        });
      });
  };

  render() {
    const { step } = this.state;
    const {
      fName,
      lName,
      email,
      userName,
      password,
      omc,
      bunkName,
      city,
      location,
      country,
      pincode,
    } = this.state;
    const values = {
      fName,
      lName,
      email,
      userName,
      password,
      omc,
      bunkName,
      city,
      location,
      country,
      pincode,
    };

    return (
      <div className="step-form-container">
        <div className="inner-wrapper">
          <div className="steps-list">
            <ul>
              <li className={`${step === 1 ? "active" : ""}`}>
                <button
                  className="toggle-step"
                  onClick={() => this.toggleStep(1)}
                >
                  Dealer Details
                </button>
              </li>
              <li className={`${step === 2 ? "active" : ""}`}>
                <button
                  className="toggle-step"
                  onClick={() => this.toggleStep(2)}
                >
                  Bunk Details
                </button>
              </li>
            </ul>
          </div>
          <div className="form-wrapper">
            {(() => {
              switch (step) {
                case 1:
                  return (
                    <StepOne
                      nextStep={this.nextStep}
                      handleChange={this.handleChange}
                      values={values}
                      error={this.state.error}
                    />
                  );
                case 2:
                  return (
                    <StepTwo
                      nextStep={this.nextStep}
                      prevStep={this.prevStep}
                      handleChange={this.handleChange}
                      handleSelectChange={this.handleSelectChange}
                      values={values}
                      submitData={this.submitData}
                      error={this.state.error}
                    />
                  );
                default:
                  console.log("PetroMeter");
              }
            })()}
          </div>
        </div>
      </div>
    );
  }
}

export default FormWizard;
