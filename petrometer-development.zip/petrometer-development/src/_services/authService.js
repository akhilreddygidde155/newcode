import { BehaviorSubject, EMPTY } from 'rxjs';


import { handleResponse } from '@H';

const apiUrl = `${process.env.API_URL}`;
const currentUserSubject = new BehaviorSubject(JSON.parse(localStorage.getItem('currentUser')));
const currentBunkSubject = new BehaviorSubject(JSON.parse(localStorage.getItem('currentBunk')));
const loginTimeSubject = new BehaviorSubject(JSON.parse(localStorage.getItem('lknoas')));

export const authService = {
    login,
    logout,
    bunkDetails,
    currentUser: currentUserSubject.asObservable(),
    currentBunk: currentBunkSubject.asObservable(),
    loginTime: loginTimeSubject.asObservable(),
    get currentUserValue () { return currentUserSubject.value },
    get currentUserRole () { return currentUserSubject.value.data.user_info.role.role },
    get currentUserToken () { return currentUserSubject.value.data.token.access_token },
    get currentOMC () { return currentBunkSubject.value.data[0].omc.uuid },
    get currentAccountID () { return currentUserSubject.value.data.user_info.associateAccounts[0].account_id },
    get currentLoginValidity () { return currentUserSubject.value.data.token.expires_in },
    get loginTime () { return loginTimeSubject.value },
};

function login(email, password) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    };

    return fetch(`${apiUrl}/users/login/`, requestOptions)
        .then(handleResponse)
        .then(user => {
            localStorage.setItem('currentUser', JSON.stringify(user));
            localStorage.setItem('lknoas', Date.now());
            currentUserSubject.next(user);
            loginTimeSubject.next(Date.now());
            return user;
        });
}

function bunkDetails(token) {
    const requestOptions = {
        method: 'GET',
        headers: { 'Content-Type': 'application/json',
                    'Authorization' : `Bearer ${token}` },
    };

    return fetch(`${apiUrl}/bunk/associate-bunks/`, requestOptions)
        .then(handleResponse)
        .then(bunk => {

            localStorage.setItem('currentBunk', JSON.stringify(bunk));
            currentBunkSubject.next(bunk);
            return bunk;
        });
}

function logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('currentBunk');
    localStorage.removeItem('lknoas');
    EMPTY;
}
