import React, { Component } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import axios from "axios";
import { ToastContainer } from "react-toastify";
import { history, Role, AuthRoute } from "@H";
import { authService } from "@S";
import Login from "@C/Login";
import {
  AdminDashboard,
  DealerDashboard,
  ManagerDashboard,
  CashierDashboard,
} from "@C/Dashboard";
import { CreateDealer } from "@C/Admin/AccountCreation";
import { BunkSetup } from "@C/Dealer/Setup/Bunk";

import "react-toastify/dist/ReactToastify.css";

const Logout = () => {
  authService.logout();
  window.location = "/";
  return true;
};

export default class Core extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      currentUser: null,
      isAdmin: false,
      isDealer: false,
      isManager: false,
      isCashier: false,
    };
  }

  componentDidMount() {
    authService.currentUser.subscribe((x) => {
      if (x) {
        this.setState({
          currentUser: x.data,
          isAdmin: x.data && x.data.user_info.role.role === Role.Admin,
          isDealer: x.data && x.data.user_info.role.role === Role.Dealer,
          isManager: x.data && x.data.user_info.role.role === Role.Manager,
          isCashier: x.data && x.data.user_info.role.role === Role.Cashier,
        });
      }
    });
  }

  render() {
    const { currentUser, isAdmin, isDealer, isCashier, isManager } = this.state;
    return (
      <Router history={history}>
        <ToastContainer />
        <Route exact path="/" component={Login} />
        <Route exact path="/login" component={Login} />
        <Route exact path="/logout" component={Logout} />
        {this.state.isAdmin && (
          <AuthRoute
            path="/dashboard"
            roles={[Role.Admin]}
            component={AdminDashboard}
          />
        )}
        {this.state.isDealer && (
          <AuthRoute
            path="/dashboard"
            roles={Role.Dealer}
            component={DealerDashboard}
          />
        )}
        {this.state.isManager && (
          <AuthRoute
            path="/dashboard"
            roles={[Role.Dealer, Role.Manager]}
            component={ManagerDashboard}
          />
        )}
        {this.state.isCashier && (
          <AuthRoute
            path="/dashboard"
            roles={[Role.Dealer, Role.Manager, Role.Cashier]}
            component={CashierDashboard}
          />
        )}

        <AuthRoute
          path="/account/admin/add/dealer"
          roles={Role.Admin}
          component={CreateDealer}
        />
        <AuthRoute
          path="/account/dealer/setup/bunk"
          roles={Role.Dealer}
          component={BunkSetup}

        />
      </Router>
    );
  }
}
