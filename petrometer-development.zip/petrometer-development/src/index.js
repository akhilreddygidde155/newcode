import React from 'react';
import ReactDom from "react-dom";
import "core-js/stable";
import "regenerator-runtime/runtime";
import Core from "./core";
import './assets/scss/style.scss';

ReactDom.render(<Core />,document.getElementById("root"));
