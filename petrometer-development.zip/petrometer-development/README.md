# PetroMeter

An interactive web app for petrol pumps to manage their day to day operations.
