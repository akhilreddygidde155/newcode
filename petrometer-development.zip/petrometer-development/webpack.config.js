const path = require("path");
const webpack = require('webpack');
const HtmlWebPackPlugin = require("html-webpack-plugin");
const dotenv = require('dotenv');
const env = dotenv.config().parsed;
const envKeys = Object.keys(env).reduce((prev, next) => {
    prev[`process.env.${next}`] = JSON.stringify(env[next]);
    return prev;
  }, {});

module.exports = {
   entry: "./src/index.js",
   output: {
      filename: "main.js",
      path: path.resolve(__dirname, "dist"),
      publicPath: '/'
   },
   resolve: {
      extensions: ['.js', '.jsx'],
      alias: {
         '@C': path.resolve(__dirname, 'src/_components'),
         '@S': path.resolve(__dirname, 'src/_services'),
         '@H': path.resolve(__dirname, 'src/_helpers'),
      }
   },
   plugins: [
      new HtmlWebPackPlugin({
         template: path.resolve(__dirname, "public/index.html"),
         filename: "index.html",
      }),
      new webpack.DefinePlugin(envKeys),
   ],
   module: {
      rules: [
         {
            test: /\.js$/,
            exclude: /node_modules/,
            use: {
               loader: "babel-loader",
               options: {
                  presets: ["@babel/preset-env", "@babel/preset-react"],
               },
            },
         },
         {
            test: /\.(sa|sc|c)ss$/,
            use: [
               {
                  loader: "style-loader",
               },
               {
                  loader: "css-loader",
               },
               {
                  loader: "sass-loader",
               },
            ],
         },
      ],
   },
   devServer: {
    historyApiFallback: true,
    hot: true,
  },
  devtool : 'inline-source-map'
};
